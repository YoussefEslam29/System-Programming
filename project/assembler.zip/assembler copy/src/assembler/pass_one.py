from typing import Optional, cast

from instruction_set import (
    MemoryBlock,
    InstructionFormat,
    is_directive,
    is_supported,
    is_format4,
    lookup_opcode,
)
from preprocessor import ParsedLine
from assembler_errors import (
    DuplicateSymbolError,
    InvalidDirectiveOperandError,
    InvalidMnemonicOrDirective,
    UnidentifiedBlockNameError,
)

from . import (
    AssemblyInstruction,
    DirectiveInstruction,
    Format1Instruction,
    Format2Instruction,
    Format3Instruction,
    Format4Instruction,
)


class AssemblerPassOne:
    _USER_BLOCKS: tuple[MemoryBlock, ...] = (
        MemoryBlock.DEFAULT,
        MemoryBlock.DEFAULTB,
        MemoryBlock.CDATA,
        MemoryBlock.CBLKS,
    )
    _USE_BLOCK_MAP: dict[str, MemoryBlock] = {
        MemoryBlock.DEFAULT.value: MemoryBlock.DEFAULT,
        MemoryBlock.DEFAULTB.value: MemoryBlock.DEFAULTB,
        MemoryBlock.CDATA.value: MemoryBlock.CDATA,
        MemoryBlock.CBLKS.value: MemoryBlock.CBLKS,
    }

    def __init__(self) -> None:
        self.default_block_loc = 0
        self.default_b_block_loc = 0
        self.cdata_block_loc = 0
        self.cblocks_block_loc = 0
        self.pool_block_loc = 0

        self.default_block_symtab: dict[str, int] = {}
        self.default_b_block_symtab: dict[str, int] = {}
        self.cdata_block_symtab: dict[str, int] = {}
        self.cblocks_block_symtab: dict[str, int] = {}
        self.pool_block_symtab: dict[str, int] = {}

        self.instructions: list[AssemblyInstruction] = []
        self.start_address = 0
        self.program_name = ""

        self._pending_literals: list[str] = []
        self._pending_literals_set: set[str] = set()
        self._pool_anchor_block: Optional[MemoryBlock] = None

    def _block_symtab(self, block: MemoryBlock) -> dict[str, int]:
        match block:
            case MemoryBlock.DEFAULT:
                return self.default_block_symtab
            case MemoryBlock.DEFAULTB:
                return self.default_b_block_symtab
            case MemoryBlock.CDATA:
                return self.cdata_block_symtab
            case MemoryBlock.CBLKS:
                return self.cblocks_block_symtab
            case MemoryBlock.POOL:
                return self.pool_block_symtab
            case _:
                raise ValueError(f"Unsupported memory block: {block}")

    def _get_block_loc(self, block: MemoryBlock) -> int:
        match block:
            case MemoryBlock.DEFAULT:
                return self.default_block_loc
            case MemoryBlock.DEFAULTB:
                return self.default_b_block_loc
            case MemoryBlock.CDATA:
                return self.cdata_block_loc
            case MemoryBlock.CBLKS:
                return self.cblocks_block_loc
            case MemoryBlock.POOL:
                return self.pool_block_loc
            case _:
                raise ValueError(f"Unsupported memory block: {block}")

    def _set_block_loc(self, block: MemoryBlock, value: int) -> None:
        match block:
            case MemoryBlock.DEFAULT:
                self.default_block_loc = value
            case MemoryBlock.DEFAULTB:
                self.default_b_block_loc = value
            case MemoryBlock.CDATA:
                self.cdata_block_loc = value
            case MemoryBlock.CBLKS:
                self.cblocks_block_loc = value
            case MemoryBlock.POOL:
                self.pool_block_loc = value
            case _:
                raise ValueError(f"Unsupported memory block: {block}")

    def _resolve_use_block(
        self, operand: Optional[str], program_counter: int, line_no: int
    ) -> MemoryBlock:
        if operand is None:
            return MemoryBlock.DEFAULT

        block = self._USE_BLOCK_MAP.get(operand.upper())
        if block is None:
            expected = ", ".join(self._USE_BLOCK_MAP)
            raise UnidentifiedBlockNameError(
                f"Unidentified Block Name: '{operand}'. Expected one of {expected}.",
                program_counter,
                line_no,
            )
        return block

    def _set_instruction_location(
        self, instruction: AssemblyInstruction, block: MemoryBlock, location: int
    ) -> None:
        instruction.block = block
        instruction.location_counter = location

    def _get_instruction_label_operand(
        self, instruction: AssemblyInstruction
    ) -> tuple[Optional[str], Optional[str]]:
        return getattr(instruction, "label", None), getattr(instruction, "operand", None)

    def _lookup_symbol(self, symbol: str) -> Optional[int]:
        for block in (*self._USER_BLOCKS, MemoryBlock.POOL):
            symtab = self._block_symtab(block)
            if symbol in symtab:
                return symtab[symbol]
        return None

    def _lookup_symbol_entry(self, symbol: str) -> Optional[tuple[MemoryBlock, int]]:
        for block in (*self._USER_BLOCKS, MemoryBlock.POOL):
            symtab = self._block_symtab(block)
            if symbol in symtab:
                return block, symtab[symbol]
        return None

    def _add_symbol(
        self,
        symbol: str,
        block: MemoryBlock,
        value: int,
        program_counter: int,
        line_no: int,
    ) -> None:
        if self._lookup_symbol_entry(symbol) is not None:
            raise DuplicateSymbolError(
                f"Duplicate symbol definition for '{symbol}'",
                program_counter,
                line_no,
            )
        self._block_symtab(block)[symbol] = value

    def _try_parse_int(self, token: str) -> Optional[int]:
        cleaned = token.strip()
        if not cleaned:
            return None
        try:
            return int(cleaned, 0)
        except ValueError:
            return None

    def _resolve_term(self, term: str, current_loc: int, line_no: int) -> int:
        cleaned = term.strip()
        while cleaned.startswith(("#", "@")):
            cleaned = cleaned[1:]
        if cleaned.endswith(",X"):
            cleaned = cleaned[:-2]
        if cleaned == "*":
            return current_loc

        parsed_number = self._try_parse_int(cleaned)
        if parsed_number is not None:
            return parsed_number

        symbol_value = self._lookup_symbol(cleaned)
        if symbol_value is not None:
            return symbol_value

        raise InvalidDirectiveOperandError(
            f"Unable to resolve operand term '{term}'",
            current_loc,
            line_no,
        )

    def _evaluate_expression(self, expr: str, current_loc: int, line_no: int) -> int:
        expression = expr.replace(" ", "")
        if not expression:
            raise InvalidDirectiveOperandError(
                "Empty directive operand", current_loc, line_no
            )

        plus_idx = expression.find("+", 1)
        minus_idx = expression.find("-", 1)

        op_idx = -1
        operator = ""
        if plus_idx != -1 and (minus_idx == -1 or plus_idx < minus_idx):
            op_idx = plus_idx
            operator = "+"
        elif minus_idx != -1:
            op_idx = minus_idx
            operator = "-"

        if op_idx == -1:
            return self._resolve_term(expression, current_loc, line_no)

        lhs = expression[:op_idx]
        rhs = expression[op_idx + 1 :]
        left_value = self._resolve_term(lhs, current_loc, line_no)
        right_value = self._resolve_term(rhs, current_loc, line_no)
        return left_value + right_value if operator == "+" else left_value - right_value

    def _parse_required_non_negative_operand(
        self,
        operand: Optional[str],
        current_loc: int,
        line_no: int,
        directive_name: str,
    ) -> int:
        if operand is None:
            raise InvalidDirectiveOperandError(
                f"Directive '{directive_name}' requires an operand",
                current_loc,
                line_no,
            )

        value = self._evaluate_expression(operand, current_loc, line_no)
        if value < 0:
            raise InvalidDirectiveOperandError(
                f"Directive '{directive_name}' requires a non-negative operand",
                current_loc,
                line_no,
            )
        return value

    def _byte_operand_size(
        self, operand: Optional[str], program_counter: int, line_no: int
    ) -> int:
        if operand is None:
            raise InvalidDirectiveOperandError(
                "Directive 'BYTE' requires an operand",
                program_counter,
                line_no,
            )

        cleaned = operand.strip()
        if len(cleaned) >= 3 and cleaned[1] == "'" and cleaned.endswith("'"):
            kind = cleaned[0].upper()
            payload = cleaned[2:-1]
            if kind == "C":
                return len(payload)
            if kind == "X":
                if len(payload) % 2 != 0:
                    raise InvalidDirectiveOperandError(
                        "Hex BYTE operand must contain an even number of digits",
                        program_counter,
                        line_no,
                    )
                return len(payload) // 2

        parsed_number = self._try_parse_int(cleaned)
        if parsed_number is not None:
            return 1

        raise InvalidDirectiveOperandError(
            f"Unsupported BYTE operand '{operand}'",
            program_counter,
            line_no,
        )

    def _literal_size(
        self, literal: str, program_counter: int, line_no: int
    ) -> int:
        token = literal[1:] if literal.startswith("&") else literal
        token = token.strip()

        if len(token) >= 3 and token[1] == "'" and token.endswith("'"):
            kind = token[0].upper()
            payload = token[2:-1]
            if kind == "C":
                return len(payload)
            if kind == "X":
                if len(payload) % 2 != 0:
                    raise InvalidDirectiveOperandError(
                        "Hex literal must contain an even number of digits",
                        program_counter,
                        line_no,
                    )
                return len(payload) // 2

        parsed_number = self._try_parse_int(token)
        if parsed_number is not None:
            return 3

        raise InvalidDirectiveOperandError(
            f"Unsupported literal format '{literal}'",
            program_counter,
            line_no,
        )

    def _collect_literals(self, operand: Optional[str], block: MemoryBlock) -> None:
        if operand is None:
            return

        for raw in operand.split(","):
            token = raw.strip()
            if not token.startswith("&"):
                continue
            if self._pool_anchor_block is None:
                self._pool_anchor_block = block
            if token in self.pool_block_symtab or token in self._pending_literals_set:
                continue
            self._pending_literals.append(token)
            self._pending_literals_set.add(token)

    def _flush_literal_pool(self, line_no: int) -> None:
        for literal in self._pending_literals:
            self.pool_block_symtab[literal] = self.pool_block_loc
            self.pool_block_loc += self._literal_size(
                literal, self.pool_block_loc, line_no
            )

        self._pending_literals.clear()
        self._pending_literals_set.clear()

    def _is_start_directive(self, instruction: AssemblyInstruction) -> bool:
        return (
            isinstance(instruction, DirectiveInstruction)
            and instruction.directive.upper() == "START"
        )

    def _handle_start_directive(
        self, instruction: DirectiveInstruction, line_no: int
    ) -> MemoryBlock:
        start_value = 0
        if instruction.operand is not None:
            start_value = int(instruction.operand)

        self.start_address = start_value
        if instruction.label is not None:
            self.program_name = instruction.label
        self._set_block_loc(MemoryBlock.DEFAULT, start_value)
        self._set_instruction_location(instruction, MemoryBlock.DEFAULT, start_value)

        if instruction.label is not None:
            self._add_symbol(
                instruction.label,
                MemoryBlock.DEFAULT,
                start_value,
                start_value,
                line_no,
            )

        return MemoryBlock.DEFAULT

    def _process_directive_pass_one(
        self,
        instruction: DirectiveInstruction,
        block_for_line: MemoryBlock,
        line_loc: int,
        line_no: int,
        current_block: MemoryBlock,
    ) -> MemoryBlock:
        directive = instruction.directive.upper()

        if instruction.label is not None:
            self._add_symbol(
                instruction.label,
                block_for_line,
                line_loc,
                line_loc,
                line_no,
            )

        self._collect_literals(instruction.operand, block_for_line)

        if directive == "USE":
            return self._resolve_use_block(instruction.operand, line_loc, line_no)
        if directive == "WORD":
            self._set_block_loc(block_for_line, line_loc + 3)
        elif directive == "RESW":
            words = self._parse_required_non_negative_operand(
                instruction.operand,
                current_loc=line_loc,
                line_no=line_no,
                directive_name="RESW",
            )
            self._set_block_loc(block_for_line, line_loc + (3 * words))
        elif directive == "RESB":
            bytes_count = self._parse_required_non_negative_operand(
                instruction.operand,
                current_loc=line_loc,
                line_no=line_no,
                directive_name="RESB",
            )
            self._set_block_loc(block_for_line, line_loc + bytes_count)
        elif directive == "BYTE":
            byte_size = self._byte_operand_size(instruction.operand, line_loc, line_no)
            self._set_block_loc(block_for_line, line_loc + byte_size)
        elif directive == "END":
            self._flush_literal_pool(line_no)

        return current_block

    def _process_machine_instruction_pass_one(
        self,
        instruction: AssemblyInstruction,
        block_for_line: MemoryBlock,
        line_loc: int,
        line_no: int,
    ) -> None:
        label, operand = self._get_instruction_label_operand(instruction)
        if label is not None:
            self._add_symbol(label, block_for_line, line_loc, line_loc, line_no)

        self._collect_literals(operand, block_for_line)
        self._set_block_loc(block_for_line, line_loc + instruction.size)

    def _parse_instruction(
        self, line: ParsedLine, current_block_loc: int = 0
    ) -> AssemblyInstruction:
        label: Optional[str] = None
        mnemonic: Optional[str] = None
        operand: Optional[str] = None

        if line.number_of_parts == 1:
            mnemonic = line.first
        elif line.number_of_parts == 2:
            assert line.second is not None
            if is_supported(line.first):
                mnemonic = line.first
                operand = line.second
            elif is_supported(line.second):
                label = line.first
                mnemonic = line.second
            else:
                raise InvalidMnemonicOrDirective(
                    f"Neither '{line.first}' nor '{line.second}' is a valid opcode or directive",
                    current_block_loc,
                    line.line_no,
                )
        else:
            assert line.second is not None
            label = line.first
            mnemonic = line.second
            operand = line.third

        if not mnemonic or not is_supported(mnemonic):
            raise InvalidMnemonicOrDirective(
                f"'{mnemonic}' is not a valid opcode or directive",
                current_block_loc,
                line.line_no,
            )

        if mnemonic.upper() == "USE":
            self._resolve_use_block(operand, current_block_loc, line.line_no)

        if is_directive(mnemonic):
            return DirectiveInstruction(
                parsed_line=line,
                size=0,
                label=label,
                directive=mnemonic,
                operand=operand,
            )

        opcode_info = lookup_opcode(mnemonic)
        if opcode_info is not None:
            if is_format4(mnemonic):
                return Format4Instruction(
                    parsed_line=line,
                    size=4,
                    label=label,
                    mnemonic=mnemonic,
                    operand=operand,
                )
            if opcode_info.fmt == InstructionFormat.FORMAT_1:
                return Format1Instruction(
                    parsed_line=line,
                    size=1,
                    label=label,
                    mnemonic=mnemonic,
                )
            if opcode_info.fmt == InstructionFormat.FORMAT_2:
                return Format2Instruction(
                    parsed_line=line,
                    size=2,
                    label=label,
                    mnemonic=mnemonic,
                    operand=operand,
                )
            if opcode_info.fmt == InstructionFormat.FORMAT_3:
                return Format3Instruction(
                    parsed_line=line,
                    size=3,
                    label=label,
                    mnemonic=mnemonic,
                    operand=operand,
                )

        raise InvalidMnemonicOrDirective(
            f"Failed to resolve formatting for '{mnemonic}'",
            current_block_loc,
            line.line_no,
        )

    def process_pass_one(self, parsed_lines: list[ParsedLine]) -> None:
        current_block = MemoryBlock.DEFAULT

        for line in parsed_lines:
            current_block_loc = self._get_block_loc(current_block)
            instruction = self._parse_instruction(line, current_block_loc)

            if self._is_start_directive(instruction):
                current_block = self._handle_start_directive(
                    cast(DirectiveInstruction, instruction),
                    line.line_no,
                )
                self.instructions.append(instruction)
                continue

            block_for_line = current_block
            line_loc = self._get_block_loc(block_for_line)
            self._set_instruction_location(instruction, block_for_line, line_loc)

            if isinstance(instruction, DirectiveInstruction):
                current_block = self._process_directive_pass_one(
                    instruction,
                    block_for_line,
                    line_loc,
                    line.line_no,
                    current_block,
                )
            else:
                self._process_machine_instruction_pass_one(
                    instruction,
                    block_for_line,
                    line_loc,
                    line.line_no,
                )

            self.instructions.append(instruction)

        if self._pending_literals:
            fallback_line_no = parsed_lines[-1].line_no if parsed_lines else 0
            self._flush_literal_pool(fallback_line_no)

    def export_symbol_table(self, output_path: str) -> None:
        rows: list[tuple[str, str, int]] = []
        for block in self._USER_BLOCKS:
            for symbol, loc in self._block_symtab(block).items():
                rows.append((symbol, block.value, loc))

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"{'Symbol':<12}{'Block':<10}{'LC (HEX)':<10}{'LC (DEC)'}\n")
            f.write("-" * 42 + "\n")
            for symbol, block_name, loc in rows:
                f.write(f"{symbol:<12}{block_name:<10}{loc:04X}{loc:>10}\n")

    def export_pool_table(self, output_path: str) -> None:
        if self._pending_literals:
            self._flush_literal_pool(0)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"{'Literal':<12}{'LC (HEX)':<10}{'LC (DEC)'}\n")
            f.write("-" * 34 + "\n")
            for literal, loc in self.pool_block_symtab.items():
                f.write(f"{literal:<12}{loc:04X}{loc:>10}\n")

    def export_intermediate_table(self, output_path: str) -> None:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("Location counter  Symbol   Instructions  Reference\n")
            f.write("----------------  -------  ------------  ----------\n")

            for instruction in self.instructions:
                label = getattr(instruction, "label", None) or ""
                operand = getattr(instruction, "operand", None) or ""

                if isinstance(instruction, DirectiveInstruction):
                    mnemonic_or_directive = instruction.directive
                    hide_location = instruction.directive.upper() == "USE"
                else:
                    mnemonic_or_directive = getattr(instruction, "mnemonic", "")
                    hide_location = False

                if instruction.location_counter is None or hide_location:
                    location = ""
                else:
                    location = f"{instruction.location_counter:04X}"

                row = (
                    f"{location:<16}  "
                    f"{label:<9}"
                    f"{mnemonic_or_directive:<14}"
                    f"{operand}"
                ).rstrip()
                f.write(row + "\n")

    @property
    def block_locs(self) -> dict[MemoryBlock, int]:
        return {
            block: self._get_block_loc(block)
            for block in (*self._USER_BLOCKS, MemoryBlock.POOL)
        }

    @property
    def symbol_tables(self) -> dict[MemoryBlock, dict[str, int]]:
        return {
            block: dict(self._block_symtab(block))
            for block in (*self._USER_BLOCKS, MemoryBlock.POOL)
        }

    @property
    def pool_anchor_block(self) -> Optional[MemoryBlock]:
        return self._pool_anchor_block
